#As per the requirements of Dr. Min
pwd
ls

cd dir1
pwd
ls

cd dir4
pwd
ls

cd ../..

cd dir2
pwd
ls

cd dir5
pwd
ls

cd ../..

cd dir3
pwd
ls

