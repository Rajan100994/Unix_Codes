#An attempt to print the required things recursively using the find command 
find . -print -ls